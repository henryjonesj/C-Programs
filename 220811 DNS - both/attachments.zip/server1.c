#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<errno.h>
struct records
{
	char dname[1024];
	char ipadd[1024];
}rec[5];
int main()
{
	int sockfd,connected;
	char send_data[1024],recv_data[1024];	
	struct sockaddr_in server1,server;
	int sin_len;
	int j=0;
	if((sockfd=socket(AF_INET,SOCK_DGRAM,0))==-1)
	{
		perror("Socket: ");
		exit(1);
	}
	int i=0;
	server1.sin_family=AF_INET;
        server1.sin_port=htons(2000);
        server1.sin_addr.s_addr=INADDR_ANY;
        bzero(&(server1.sin_zero),8);
	sin_len=sizeof(struct sockaddr_in);
	strcpy(rec[0].dname,"www.google.com");
	strcpy(rec[0].ipadd,"10.0.0.0");
	strcpy(rec[1].dname,"www.yahoo.com");
	strcpy(rec[1].ipadd,"10.0.0.1");
	strcpy(rec[2].dname,"www.in.com");
	strcpy(rec[2].ipadd,"10.0.0.2");
	strcpy(rec[3].dname,"www.facebook.com");
	strcpy(rec[3].ipadd,"10.0.0.3");
	if(bind(sockfd,(struct sockaddr *)&server1,sizeof(struct sockaddr))==-1)
	{
		perror("Bind: ");
		exit(1);
	}
	printf("\nBind Successful.\n");
	while(1)
	{
		printf("\n ");
		recvfrom(sockfd,recv_data,sizeof(recv_data),0,(struct sockaddr  *)&server,&sin_len);
		printf("Received Data from Server: %s",recv_data);
                if(strcmp(recv_data,"quit")==0){close(sockfd);exit(0);}
		if(strncmp(recv_data,"www.",4)==0)
		{	
			for(j=0;j<4;j++)
			{
				if(strcmp(recv_data,rec[j].dname)==0)
				{
					printf("\nIPAddress for %s is %s",recv_data,rec[j].ipadd);
					strcpy(send_data,rec[j].ipadd);
					sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&server,sizeof(struct sockaddr));					
					break;
				}
			}
		}
	}
close(sockfd);
return 0;
}
