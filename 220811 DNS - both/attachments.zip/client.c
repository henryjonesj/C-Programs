#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<errno.h>
int main()
{
        int sockfd,connected;
        char send_data[1024],recv_data[1024];
        struct sockaddr_in server,client;
        int sin_len;
        if((sockfd=socket(AF_INET,SOCK_DGRAM,0))==-1)
        {
                perror("Socket: ");
                exit(1);
        }
        server.sin_family=AF_INET;
        server.sin_port=htons(8000);
	server.sin_addr.s_addr=INADDR_ANY;
        bzero(&(server.sin_zero),8);
        sin_len=sizeof(struct sockaddr_in);
	
	while(1)
	{
		
		printf("\nEnter data to send(quit): ");	
		gets(send_data);
		sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&server,sizeof(struct sockaddr));
		if(strcmp(send_data,"quit")==0){close(sockfd);exit(0);}	
		//printf("\n");
		recvfrom(sockfd,recv_data,sizeof(recv_data),0,(struct sockaddr  *)&server,&sin_len);
		printf("Response: %s",recv_data);
	}

return 0;
}
