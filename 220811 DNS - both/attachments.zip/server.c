#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<errno.h>
struct records
{
        char dname[1024];
        char ipadd[1024];
}rec[5];

int main()
{
	int sockfd,connected;
	char send_data[1024],recv_data[1024];	
	struct sockaddr_in server,client,server1;
	int sin_len;
	int i=0,j=0;
	if((sockfd=socket(AF_INET,SOCK_DGRAM,0))==-1)
	{
		perror("Socket: ");
		exit(1);
	}
	server.sin_family=AF_INET;
	server.sin_port=htons(8000);
	server.sin_addr.s_addr=INADDR_ANY;
	bzero(&(server.sin_zero),8);
	sin_len=sizeof(struct sockaddr_in);
	strcpy(rec[0].dname,"www.a.com");
        strcpy(rec[0].ipadd,"20.0.0.0");
        strcpy(rec[1].dname,"www.b.com");
        strcpy(rec[1].ipadd,"20.0.0.1");
        strcpy(rec[2].dname,"www.c.com");
        strcpy(rec[2].ipadd,"20.0.0.2");
        strcpy(rec[3].dname,"www.d.com");
        strcpy(rec[3].ipadd,"20.0.0.3");

	server1.sin_family=AF_INET;
        server1.sin_port=htons(2000);
        server1.sin_addr.s_addr=INADDR_ANY;
        bzero(&(server1.sin_zero),8);

	if(bind(sockfd,(struct sockaddr *)&server,sizeof(struct sockaddr))==-1)
	{
		perror("Bind: ");
		exit(1);
	}
	printf("\nBind Successful.\n");
	while(1)
	{
		//recv request from client and print it on stdout
		recvfrom(sockfd,recv_data,sizeof(recv_data),0,(struct sockaddr  *)&client,&sin_len);
		printf("\nReceived Data: %s",recv_data);
		
		strcpy(send_data,recv_data);
       		// printf("\n%s was Sent to Server1 also.",send_data);
	
		/*sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&server1,sizeof(struct sockaddr));*/
		if(strcmp(send_data,"quit")==0)
		{ 
			sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&server1,sizeof(struct sockaddr));
			close(sockfd);
			exit(0);
		}
		//if(strncmp(recv_data,"www.",4)==0)
        	//{
		while(1)
		{
		       i++;
		       for(j=0;j<4;j++)
		       {
				if(strcmp(recv_data,rec[j].dname)==0)
				{
		                        
					printf("\nIPAddress for %s is %s",recv_data,rec[j].ipadd);
		                        strcpy(send_data,rec[j].ipadd);
					sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&client,sizeof(struct sockaddr));
					printf("YO MAN !!!");
					i=5;
					break;
		                }
			//if(i==2)break;	
		       }	
		 
		 break;
		}
        	//} }
		if(i!=5)
		{
 			printf("\nCould not find Record.\nRequest was sent to Server1.\n");
	        	sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&server1,sizeof(struct sockaddr));
			printf("\nWaiting for Reply.\n");			
			recvfrom(sockfd,recv_data,sizeof(recv_data),0,(struct sockaddr  *)&server1,&sin_len);
			printf("Received Data from Server1: %s",recv_data);
			strcpy(send_data,recv_data);
			sendto(sockfd,send_data,sizeof(send_data),0,(struct sockaddr *)&client,sizeof(struct sockaddr));
			printf("YO MAN !!!");
		}
	}
close(sockfd);
return 0;
}
